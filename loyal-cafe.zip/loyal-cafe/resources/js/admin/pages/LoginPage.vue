<script setup>
import { ref } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { useAuth } from '../stores/auth';
import { errorMessage, fieldErrors } from '../api';

const auth = useAuth();
const router = useRouter();
const route = useRoute();
const email = ref('');
const password = ref('');
const error = ref('');
const busy = ref(false);

async function submit() {
    error.value = '';
    busy.value = true;
    try {
        await auth.login(email.value.trim(), password.value);
        router.replace(typeof route.query.next === 'string' ? route.query.next : '/');
    } catch (e) {
        const f = fieldErrors(e);
        error.value = f ? Object.values(f)[0] : e.response?.status === 429 ? 'Too many attempts. Wait a minute and try again.' : errorMessage(e);
    } finally {
        busy.value = false;
    }
}
</script>

<template>
    <div class="grid min-h-screen place-items-center bg-emerald-night px-4">
        <form class="w-full max-w-sm rounded-2xl bg-white p-8 shadow-xl" @submit.prevent="submit">
            <p class="font-display text-3xl text-emerald">Loyal</p>
            <p class="mb-8 text-sm text-stone-500">Sign in to manage the website</p>
            <label class="a-label" for="email">Email</label>
            <input id="email" v-model="email" type="email" autocomplete="username" class="a-input mb-4" required dir="ltr">
            <label class="a-label" for="password">Password</label>
            <input id="password" v-model="password" type="password" autocomplete="current-password" class="a-input" required dir="ltr">
            <p v-if="error" class="a-error mt-3" role="alert">{{ error }}</p>
            <button class="a-btn a-btn-primary mt-6 w-full" :disabled="busy">{{ busy ? 'Signing in…' : 'Sign in' }}</button>
        </form>
    </div>
</template>
