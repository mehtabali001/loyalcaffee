<script setup>
import { useSite } from '../stores/site';

defineProps({
    title: String,
    subtitle: String,
    ctaLabel: String,
    ctaLink: String,
    dark: { type: Boolean, default: false },
});
const site = useSite();
</script>

<template>
    <div class="mb-10 flex flex-wrap items-end justify-between gap-x-10 gap-y-5">
        <div class="max-w-2xl">
            <span class="gold-rule mb-5" />
            <h2 class="t-h2">{{ title }}</h2>
            <p v-if="subtitle" class="t-lead mt-3" :class="dark ? 'text-ivory/75' : 'text-charcoal/70'">{{ subtitle }}</p>
        </div>
        <router-link v-if="ctaLabel && ctaLink" :to="site.lp(ctaLink)" class="btn" :class="dark ? 'btn-ghost-light' : 'btn-ghost-dark'">
            {{ ctaLabel }}
        </router-link>
    </div>
</template>
