<script setup>
defineProps({ title: String, intro: String, dark: { type: Boolean, default: false } });
</script>

<template>
    <header class="relative overflow-hidden pb-14 pt-[calc(var(--header-h)+4rem)]" :class="dark ? 'bg-emerald-night text-ivory' : ''">
        <div v-if="dark" class="lattice absolute inset-0 opacity-[0.06]" />
        <div class="shell relative">
            <span class="gold-rule mb-6" />
            <h1 class="t-display !text-[clamp(2.6rem,6vw,4.5rem)]">{{ title }}</h1>
            <p v-if="intro" class="t-lead mt-5 max-w-2xl" :class="dark ? 'text-ivory/75' : 'text-charcoal/70'">{{ intro }}</p>
            <slot />
        </div>
    </header>
</template>
