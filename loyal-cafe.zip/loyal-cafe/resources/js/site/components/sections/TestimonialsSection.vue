<script setup>
import { computed } from 'vue';
import { useI18n } from 'vue-i18n';
import Icon from '@/shared/Icon.vue';
import { useSite } from '../../stores/site';

defineProps({ section: Object, testimonials: { type: Array, default: () => [] } });
const site = useSite();
const { t } = useI18n();
const rating = computed(() => site.settings.rating || {});
</script>

<template>
    <section class="py-24 md:py-28">
        <div class="shell grid gap-14 md:grid-cols-[0.7fr_1.3fr]">
            <div>
                <span class="gold-rule mb-6" />
                <h2 class="t-h2">{{ section.title }}</h2>
                <div v-if="rating.value" class="mt-8">
                    <p class="tabular font-display text-7xl leading-none text-emerald">{{ Number(rating.value).toFixed(1) }}</p>
                    <div class="mt-3 flex gap-1 text-gold" :aria-label="`${rating.value} / 5`">
                        <Icon v-for="n in 5" :key="n" name="star" :size="20" :class="n <= Math.round(rating.value) ? 'fill-current' : 'opacity-40'" />
                    </div>
                    <p class="mt-3 text-charcoal/70">{{ t('home.rating', { value: Number(rating.value).toFixed(1), count: rating.count }) }}</p>
                    <a v-if="rating.url" :href="rating.url" target="_blank" rel="noopener" class="btn btn-ghost-dark mt-6">
                        <Icon name="google" :size="18" /> {{ t('home.read_reviews') }}
                    </a>
                </div>
            </div>
            <div v-if="testimonials.length" class="grid gap-10 sm:grid-cols-2">
                <blockquote v-for="q in testimonials.slice(0, 4)" :key="q.id" class="border-t border-charcoal/10 pt-6">
                    <p class="font-display text-xl leading-relaxed">{{ q.content }}</p>
                    <footer class="mt-4 text-sm text-charcoal/60">{{ q.author }}</footer>
                </blockquote>
            </div>
        </div>
    </section>
</template>
