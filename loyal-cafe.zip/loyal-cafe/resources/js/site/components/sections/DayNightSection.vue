<script setup>
import Icon from '@/shared/Icon.vue';

defineProps({ section: { type: Object, required: true } });
</script>

<template>
    <section aria-labelledby="daynight-title">
        <h2 id="daynight-title" class="sr-only">{{ section.title }}</h2>
        <div class="grid md:grid-cols-2">
            <article
                v-for="key in ['day', 'night']" :key="key"
                class="relative isolate flex min-h-[34rem] flex-col justify-end overflow-hidden p-8 sm:p-12"
                :class="key === 'day' ? 'bg-ivory-deep text-charcoal' : 'bg-emerald-night text-ivory'"
            >
                <template v-if="section.data?.[key]?.image">
                    <img :src="section.data[key].image" alt="" loading="lazy" class="absolute inset-0 -z-20 h-full w-full object-cover">
                    <div class="absolute inset-0 -z-10" :class="key === 'day' ? 'bg-gradient-to-t from-ivory-deep via-ivory-deep/85 to-ivory-deep/10' : 'bg-gradient-to-t from-emerald-night via-emerald-night/85 to-emerald-night/20'" />
                </template>
                <p class="mb-4 flex items-center gap-2 text-sm" :class="key === 'day' ? 'text-terracotta' : 'text-gold'">
                    <Icon :name="key === 'day' ? 'sun' : 'moon'" :size="18" />
                    {{ section.data?.[key]?.time }}
                </p>
                <h3 class="t-h2">{{ section.data?.[key]?.title }}</h3>
                <p class="t-lead mt-4 max-w-md" :class="key === 'day' ? 'text-charcoal/75' : 'text-ivory/75'">{{ section.data?.[key]?.body }}</p>
            </article>
        </div>
    </section>
</template>
