<script setup>
import { computed } from 'vue';
import { useI18n } from 'vue-i18n';
import SmokeLine from '../SmokeLine.vue';
import OpenStatus from '../OpenStatus.vue';
import Icon from '@/shared/Icon.vue';
import { useSite } from '../../stores/site';

/**
 * The hero follows the clock in Madinat Zayed: before 5 PM it opens on the ivory, coffee-lit
 * "day" layout; after 5 PM on the full-bleed emerald "night" lounge. Guests can flip it.
 */
const props = defineProps({ section: { type: Object, required: true } });
const site = useSite();
const { t } = useI18n();

const night = computed(() => site.heroMood === 'night');
const img = computed(() => (night.value ? props.section.image_secondary || props.section.image : props.section.image || props.section.image_secondary));
const d = computed(() => props.section.data || {});
const rating = computed(() => site.settings.rating);
</script>

<template>
    <section
        class="relative isolate overflow-hidden transition-colors duration-700"
        :class="night ? 'bg-emerald-night text-ivory' : 'bg-ivory text-charcoal'"
        aria-labelledby="hero-title"
    >
        <!-- Night: full-bleed photograph under an emerald wash -->
        <template v-if="night">
            <img v-if="img" :src="img" alt="" class="absolute inset-0 -z-20 h-full w-full object-cover" fetchpriority="high">
            <div class="absolute inset-0 -z-10 bg-gradient-to-t from-emerald-night via-emerald-night/75 to-emerald-night/30" />
            <div class="lattice absolute inset-0 -z-10 opacity-[0.06]" />
        </template>

        <div
            class="shell grid min-h-[92svh] items-end gap-10 pb-14 pt-[calc(var(--header-h)+3rem)]"
            :class="night ? '' : 'lg:grid-cols-[1.1fr_0.9fr] lg:items-center'"
        >
            <div class="max-w-3xl">
                <OpenStatus class="mb-8" />
                <h1 id="hero-title" class="t-display">{{ section.title }}</h1>
                <SmokeLine :key="site.heroMood" class="mt-2" :class="night ? 'text-gold' : 'text-terracotta'" />
                <p v-if="section.subtitle" class="t-lead mt-6 max-w-xl" :class="night ? 'text-ivory/80' : 'text-charcoal/75'">
                    {{ section.subtitle }}
                </p>

                <div class="mt-10 flex flex-wrap items-center gap-3">
                    <router-link v-if="section.cta_label" :to="site.lp(section.cta_link || '/reserve')" class="btn btn-gold">
                        {{ section.cta_label }}
                    </router-link>
                    <router-link v-if="d.secondary_label" :to="site.lp(d.secondary_link || '/menu')" class="btn" :class="night ? 'btn-ghost-light' : 'btn-ghost-dark'">
                        {{ d.secondary_label }}
                    </router-link>
                </div>

                <div class="mt-12 flex flex-wrap items-center gap-x-8 gap-y-4 text-sm">
                    <a
                        v-if="rating?.value" :href="rating.url || '#'" target="_blank" rel="noopener"
                        class="flex items-center gap-2 hover:underline" :class="night ? 'text-ivory/80' : 'text-charcoal/70'"
                    >
                        <Icon name="star" :size="16" class="text-gold" />
                        {{ t('home.rating', { value: Number(rating.value).toFixed(1), count: rating.count }) }}
                    </a>

                    <div class="inline-flex rounded-full border p-1" :class="night ? 'border-ivory/20' : 'border-charcoal/15'" role="group" :aria-label="t('home.mood')">
                        <button
                            v-for="m in ['day', 'night']" :key="m" type="button" :aria-pressed="site.heroMood === m"
                            class="flex items-center gap-1.5 rounded-full px-3.5 py-1.5 transition-colors"
                            :class="site.heroMood === m ? 'bg-gold text-charcoal' : 'opacity-70 hover:opacity-100'"
                            @click="site.heroMood = m"
                        >
                            <Icon :name="m === 'day' ? 'sun' : 'moon'" :size="16" />
                            {{ t(m === 'day' ? 'home.by_day' : 'home.by_night') }}
                        </button>
                    </div>
                </div>
            </div>

            <!-- Day: photograph framed in an arch, a nod to Arabic doorways -->
            <figure v-if="!night && img" class="relative mx-auto hidden w-full max-w-md lg:block">
                <div class="aspect-[4/5] overflow-hidden rounded-t-full border border-gold/50 p-2">
                    <img :src="img" alt="" class="h-full w-full rounded-t-full object-cover" fetchpriority="high">
                </div>
            </figure>
        </div>
    </section>
</template>
