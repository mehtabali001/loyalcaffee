<script setup>
import { computed } from 'vue';

const props = defineProps({ section: { type: Object, required: true } });
const paragraphs = computed(() => (props.section.body || '').split(/\n{2,}/).filter(Boolean));
</script>

<template>
    <section class="py-24 md:py-32">
        <div class="shell grid items-center gap-14 md:grid-cols-[0.8fr_1fr]">
            <figure v-if="section.image" class="order-last mx-auto w-full max-w-sm md:order-first">
                <img :src="section.image" alt="" loading="lazy" class="aspect-[3/4] w-full rounded-t-full object-cover">
            </figure>
            <div class="max-w-prose">
                <span class="gold-rule mb-6" />
                <h2 class="t-h2">{{ section.title }}</h2>
                <p v-for="(p, i) in paragraphs" :key="i" class="mt-6 text-charcoal/80" :class="i === 0 ? 't-lead font-display text-charcoal' : ''">
                    {{ p }}
                </p>
            </div>
        </div>
    </section>
</template>
