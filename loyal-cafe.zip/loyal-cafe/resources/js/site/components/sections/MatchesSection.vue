<script setup>
import { useI18n } from 'vue-i18n';
import SectionHeading from '../SectionHeading.vue';
import MatchRow from '../MatchRow.vue';
import { useSite } from '../../stores/site';

defineProps({ section: Object, events: { type: Array, default: () => [] } });
const { t } = useI18n();
const site = useSite();
</script>

<template>
    <section class="relative isolate overflow-hidden bg-emerald-night py-24 text-ivory md:py-28">
        <img v-if="section.image" :src="section.image" alt="" loading="lazy" class="absolute inset-0 -z-20 h-full w-full object-cover opacity-25">
        <div class="lattice absolute inset-0 -z-10 opacity-[0.05]" />
        <div class="shell">
            <SectionHeading dark :title="section.title" :subtitle="section.subtitle" :cta-label="events.length ? section.cta_label : null" :cta-link="section.cta_link" />
            <div v-if="events.length" class="border-t border-ivory/10">
                <MatchRow v-for="e in events" :key="e.id" :event="e" />
            </div>
            <p v-else class="max-w-prose text-ivory/75">
                {{ t('home.no_matches') }}
                <a v-if="site.whatsappLink()" :href="site.whatsappLink()" target="_blank" rel="noopener" class="text-gold underline">{{ t('cta.whatsapp') }}</a>
            </p>
        </div>
    </section>
</template>
