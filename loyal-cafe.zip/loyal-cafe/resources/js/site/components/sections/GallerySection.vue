<script setup>
import SectionHeading from '../SectionHeading.vue';

defineProps({ section: Object, gallery: { type: Array, default: () => [] } });
</script>

<template>
    <section v-if="gallery.length" class="py-24 md:py-28">
        <div class="shell">
            <SectionHeading :title="section.title" :subtitle="section.subtitle" :cta-label="section.cta_label" :cta-link="section.cta_link" />
            <!-- Editorial mosaic: first image leads, the rest follow at half size -->
            <div class="grid auto-rows-[11rem] grid-cols-2 gap-3 sm:auto-rows-[14rem] md:grid-cols-4">
                <figure
                    v-for="(g, i) in gallery.slice(0, 5)" :key="g.id"
                    class="overflow-hidden rounded-lg bg-ivory-deep"
                    :class="i === 0 ? 'col-span-2 row-span-2' : ''"
                >
                    <img :src="g.image" :alt="g.alt || ''" loading="lazy" class="h-full w-full object-cover transition-transform duration-700 ease-lounge hover:scale-[1.03]">
                </figure>
            </div>
        </div>
    </section>
</template>
