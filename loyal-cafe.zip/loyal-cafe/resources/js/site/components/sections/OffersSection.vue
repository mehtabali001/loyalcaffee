<script setup>
import { useSite } from '../../stores/site';
import SectionHeading from '../SectionHeading.vue';

defineProps({ section: Object });
const site = useSite();
</script>

<template>
    <section v-if="site.offers.length" class="bg-ivory-deep py-20">
        <div class="shell">
            <SectionHeading :title="section.title" :subtitle="section.subtitle" />
            <div class="grid gap-10 md:grid-cols-3">
                <article v-for="o in site.offers" :key="o.id" class="border-s border-gold ps-6">
                    <img v-if="o.image" :src="o.image" alt="" loading="lazy" class="mb-5 aspect-[4/3] w-full rounded-lg object-cover">
                    <p v-if="o.badge" class="text-sm font-semibold text-terracotta">{{ o.badge }}</p>
                    <h3 class="t-h3 mt-2">{{ o.title }}</h3>
                    <p class="mt-2 text-charcoal/70">{{ o.description }}</p>
                    <router-link v-if="o.cta_link" :to="site.lp(o.cta_link)" class="mt-4 inline-block font-semibold text-emerald underline-offset-4 hover:underline">
                        {{ $t(o.cta_link.includes('reserve') ? 'cta.reserve' : o.cta_link.includes('menu') ? 'cta.view_menu' : 'cta.more') }}
                    </router-link>
                </article>
            </div>
        </div>
    </section>
</template>
