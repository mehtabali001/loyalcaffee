<script setup>
import SectionHeading from '../SectionHeading.vue';
import MenuLine from '../MenuLine.vue';

defineProps({ section: Object, featured: { type: Array, default: () => [] } });
</script>

<template>
    <section v-if="featured.length" class="py-24 md:py-28">
        <div class="shell">
            <SectionHeading :title="section.title" :subtitle="section.subtitle" :cta-label="section.cta_label" :cta-link="section.cta_link" />
            <div class="grid gap-x-16 md:grid-cols-2">
                <MenuLine v-for="item in featured" :key="item.id" :item="item" />
            </div>
        </div>
    </section>
</template>
