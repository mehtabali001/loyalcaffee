<script setup>
import { computed } from 'vue';
import { useI18n } from 'vue-i18n';
import Icon from '@/shared/Icon.vue';
import Logo from './Logo.vue';
import HoursTable from './HoursTable.vue';
import { useSite } from '../stores/site';

const site = useSite();
const { t } = useI18n();
const s = computed(() => site.settings);
const socials = computed(() => Object.entries(s.value.socials || {}).filter(([, url]) => url));
const year = new Date().getFullYear();
</script>

<template>
    <footer class="relative overflow-hidden bg-emerald-night text-ivory">
        <div class="lattice pointer-events-none absolute inset-0 opacity-[0.05]" />
        <div class="shell relative grid gap-12 py-16 md:grid-cols-[1.2fr_1fr_1fr]">
            <div class="max-w-xs">
                <Logo light />
                <p class="mt-5 font-display text-2xl text-gold-soft">{{ s.tagline }}</p>
                <div v-if="socials.length" class="mt-8">
                    <p class="mb-3 text-sm text-ivory/60">{{ t('footer.follow') }}</p>
                    <div class="flex gap-2">
                        <a
                            v-for="[name, url] in socials" :key="name" :href="url" target="_blank" rel="noopener"
                            class="grid h-11 w-11 place-items-center rounded-full border border-ivory/15 transition-colors hover:border-gold hover:text-gold"
                            :aria-label="name"
                        ><Icon :name="name" :size="20" /></a>
                    </div>
                </div>
            </div>

            <div>
                <h2 class="mb-4 font-display text-lg">{{ t('home.hours_title') }}</h2>
                <HoursTable dark />
            </div>

            <address class="not-italic">
                <h2 class="mb-4 font-display text-lg">{{ t('contact.address') }}</h2>
                <p class="text-ivory/80">{{ s.address?.street }}<br>{{ s.address?.area }}</p>
                <a v-if="s.maps?.directions_url" :href="s.maps.directions_url" target="_blank" rel="noopener" class="mt-2 inline-flex items-center gap-2 text-gold hover:underline">
                    <Icon name="pin" :size="18" /> {{ t('cta.directions') }}
                </a>
                <p class="mt-5">
                    <a v-if="site.telLink" :href="site.telLink" class="tabular text-lg hover:text-gold" dir="ltr">{{ s.phone }}</a>
                </p>
            </address>
        </div>
        <div class="shell relative flex flex-wrap items-center justify-between gap-3 border-t border-ivory/10 py-6 text-sm text-ivory/50">
            <p>© {{ year }} {{ s.site_name }}. {{ t('footer.rights') }}</p>
            <nav class="flex gap-5">
                <router-link :to="site.lp('/menu')" class="hover:text-ivory">{{ t('nav.menu') }}</router-link>
                <router-link :to="site.lp('/reserve')" class="hover:text-ivory">{{ t('nav.reserve') }}</router-link>
                <router-link :to="site.lp('/contact')" class="hover:text-ivory">{{ t('nav.contact') }}</router-link>
            </nav>
        </div>
    </footer>
</template>
