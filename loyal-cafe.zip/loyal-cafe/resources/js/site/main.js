import { createApp } from 'vue';
import { createPinia } from 'pinia';
import App from './App.vue';
import { makeRouter } from './router';
import { makeI18n } from './i18n';
import { useSite } from './stores/site';

const boot = window.__LOYAL__ || {};
const app = createApp(App);
const pinia = createPinia();
app.use(pinia);

const site = useSite();
app.use(makeI18n(site.locale, boot.messages || {}));
app.use(makeRouter(site.locales));

// The server already set <html lang/dir>; this keeps them honest if the shell was cached.
document.documentElement.lang = site.locale;
document.documentElement.dir = site.rtl ? 'rtl' : 'ltr';

app.mount('#app');
