<script setup>
import { computed, reactive, ref, watch } from 'vue';
import { useRoute } from 'vue-router';
import { useI18n } from 'vue-i18n';
import Icon from '@/shared/Icon.vue';
import PageIntro from '../components/PageIntro.vue';
import HoursTable from '../components/HoursTable.vue';
import { useSite } from '../stores/site';
import { CAFE_TZ, formatClock, formatDate } from '../composables/useTime';
import { validationErrors } from '@/shared/http';

const site = useSite();
const route = useRoute();
const { t, locale } = useI18n();

const cfg = computed(() => site.settings.reservation || {});
const enabled = computed(() => cfg.value.enabled !== false);
const step = computed(() => Number(cfg.value.slot_minutes) || 30);
const lead = computed(() => Number(cfg.value.lead_minutes) || 30);

/* ---------- Dates in the cafe's timezone ---------- */
const ymd = (d) => new Intl.DateTimeFormat('en-CA', { timeZone: CAFE_TZ }).format(d); // YYYY-MM-DD
const addDays = (s, n) => {
    const d = new Date(`${s}T12:00:00Z`);
    d.setUTCDate(d.getUTCDate() + n);
    return d.toISOString().slice(0, 10);
};
const weekday = (s) => new Date(`${s}T12:00:00Z`).getUTCDay();
const toMin = (hhmm) => { const [h, m] = String(hhmm).split(':').map(Number); return h * 60 + m; };
const hhmm = (min) => `${String(Math.floor(min / 60) % 24).padStart(2, '0')}:${String(min % 60).padStart(2, '0')}`;
/** Minutes from now (cafe clock) until a given local date + time. */
const nowStamp = () => {
    const p = Object.fromEntries(new Intl.DateTimeFormat('en-GB', {
        timeZone: CAFE_TZ, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
    }).formatToParts(new Date()).map((x) => [x.type, x.value]));
    return Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute);
};
const stamp = (date, time) => Date.parse(`${date}T${time}:00Z`);

const today = ymd(new Date());
const maxDate = addDays(today, 89);

/* ---------- Form ---------- */
const blank = () => ({ name: '', phone: '', email: '', guests: 2, date: today, slot: '', seating: '', event_id: '', notes: '', website: '' });
const form = reactive(blank());
const errors = ref({});
const sending = ref(false);
const failed = ref(false);
const done = ref(null);

/**
 * The visitor picks the *visit day*; slots run through that day's shift, so a 01:00 slot on a
 * 08:00→03:00 shift is really the next calendar morning. Each slot therefore carries its own date.
 */
const shift = computed(() => (site.settings.hours || []).find((h) => h.day === weekday(form.date)));
const slots = computed(() => {
    const h = shift.value;
    if (!h || h.closed) return [];
    const open = toMin(h.open);
    let close = toMin(h.close);
    if (close <= open) close += 1440;
    const earliest = nowStamp() + lead.value * 60_000;
    const out = [];
    // Last seating one slot before closing
    for (let m = Math.ceil(open / step.value) * step.value; m <= close - step.value; m += step.value) {
        const date = m >= 1440 ? addDays(form.date, 1) : form.date;
        const time = hhmm(m);
        if (stamp(date, time) < earliest) continue;
        out.push({ value: `${date} ${time}`, date, time, late: m >= 1440 });
    }
    return out;
});
const closedDay = computed(() => shift.value?.closed === true);

watch(slots, (list) => {
    if (!list.some((s) => s.value === form.slot)) form.slot = list[0]?.value || '';
}, { immediate: true });

/* ---------- Match nights ---------- */
const events = ref([]);
site.load('events', '/events').then((d) => (events.value = (d.events || []).filter((e) => e.reservations_open))).catch(() => {});
const eventLabel = (e) => {
    const teams = e.home_team && e.away_team ? `${e.home_team} – ${e.away_team}` : e.title;
    return `${teams} · ${formatDate(e.starts_at, locale.value, { weekday: 'short', day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' })}`;
};

/** Choosing a match moves the booking to half an hour before kick-off, facing the screens. */
function applyEvent(id) {
    const e = events.value.find((x) => String(x.id) === String(id));
    if (!e) return;
    const k = new Date(e.starts_at);
    const date = ymd(k);
    const [hh, mm] = new Intl.DateTimeFormat('en-GB', { timeZone: CAFE_TZ, hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(k).split(':').map(Number);
    let m = Math.floor((hh * 60 + mm - 30) / step.value) * step.value;
    // An after-midnight kick-off belongs to the previous visit day
    let visit = date;
    if (m < toMin(shift.value?.open || '08:00') && hh < 6) { visit = addDays(date, -1); m += 1440; }
    form.date = visit;
    const want = `${m >= 1440 ? date : visit} ${hhmm(m)}`;
    setTimeout(() => { if (slots.value.some((s) => s.value === want)) form.slot = want; });
    if (!form.seating) form.seating = 'screens';
}
watch(() => form.event_id, (id) => id && applyEvent(id));
watch(events, () => { if (route.query.match) form.event_id = String(route.query.match); }, { once: true });

/* ---------- Submit ---------- */
async function submit() {
    errors.value = {};
    failed.value = false;
    sending.value = true;
    const s = slots.value.find((x) => x.value === form.slot);
    try {
        const { data } = await site.http().post('/reservations', {
            name: form.name.trim(),
            phone: form.phone.trim(),
            email: form.email.trim() || null,
            guests: Number(form.guests),
            date: s?.date || form.date,
            time: s?.time || '',
            seating: form.seating || null,
            event_id: form.event_id ? Number(form.event_id) : null,
            notes: form.notes.trim() || null,
            website: form.website,
        });
        done.value = data.reference;
        window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (e) {
        const v = validationErrors(e);
        if (v) {
            if (v.date || v.time) v.slot = v.time || v.date;
            errors.value = v;
        } else failed.value = true;
    } finally {
        sending.value = false;
    }
}

function again() {
    Object.assign(form, blank());
    done.value = null;
}

const summaryText = computed(() => {
    if (!done.value) return '';
    return locale.value === 'ar'
        ? `مرحباً، أرسلت طلب حجز رقم ${done.value}.`
        : `Hi, I just sent booking request ${done.value}.`;
});
const guestOptions = computed(() => {
    const max = Math.min(Number(cfg.value.max_guests) || 30, 30);
    return Array.from({ length: max - (Number(cfg.value.min_guests) || 1) + 1 }, (_, i) => i + (Number(cfg.value.min_guests) || 1));
});
</script>

<template>
    <div>
        <PageIntro :title="t('reserve.title')" :intro="t('reserve.intro')" />

        <div class="shell grid gap-14 pb-24 lg:grid-cols-[minmax(0,1fr)_20rem]">
            <!-- Success -->
            <section v-if="done" class="max-w-xl rounded-2xl border border-emerald/20 bg-white/60 p-8" aria-live="polite">
                <Icon name="check" :size="36" class="text-emerald" />
                <h2 class="t-h3 mt-4">{{ t('reserve.done_title') }}</h2>
                <p class="mt-3 text-charcoal/75">{{ t('reserve.done_body', { ref: done }) }}</p>
                <p class="mt-6 font-mono text-2xl tracking-wider text-emerald" dir="ltr">{{ done }}</p>
                <div class="mt-8 flex flex-wrap gap-3">
                    <a v-if="site.whatsappLink(summaryText)" :href="site.whatsappLink(summaryText)" target="_blank" rel="noopener" class="btn btn-emerald">
                        <Icon name="whatsapp" :size="18" /> {{ t('cta.whatsapp') }}
                    </a>
                    <button type="button" class="btn btn-ghost-dark" @click="again">{{ t('reserve.another') }}</button>
                </div>
            </section>

            <!-- Paused -->
            <section v-else-if="!enabled" class="max-w-xl">
                <p class="t-lead text-charcoal/80">{{ t('reserve.paused') }}</p>
                <div class="mt-8 flex flex-wrap gap-3">
                    <a v-if="site.telLink" :href="site.telLink" class="btn btn-emerald"><Icon name="phone" :size="18" /> {{ t('cta.call') }}</a>
                    <a v-if="site.whatsappLink()" :href="site.whatsappLink()" target="_blank" rel="noopener" class="btn btn-ghost-dark"><Icon name="whatsapp" :size="18" /> {{ t('cta.whatsapp') }}</a>
                </div>
            </section>

            <!-- Form -->
            <form v-else class="grid max-w-2xl gap-6 sm:grid-cols-2" novalidate @submit.prevent="submit">
                <div class="sm:col-span-2">
                    <label class="label" for="r-name">{{ t('reserve.name') }}</label>
                    <input id="r-name" v-model="form.name" class="field" autocomplete="name" required maxlength="80" :aria-invalid="!!errors.name">
                    <p v-if="errors.name" class="mt-1 text-sm text-terracotta">{{ errors.name }}</p>
                </div>
                <div>
                    <label class="label" for="r-phone">{{ t('reserve.phone') }}</label>
                    <input id="r-phone" v-model="form.phone" class="field" type="tel" dir="ltr" inputmode="tel" autocomplete="tel" placeholder="05X XXX XXXX" required :aria-invalid="!!errors.phone">
                    <p v-if="errors.phone" class="mt-1 text-sm text-terracotta">{{ errors.phone }}</p>
                </div>
                <div>
                    <label class="label" for="r-email">{{ t('reserve.email') }}</label>
                    <input id="r-email" v-model="form.email" class="field" type="email" dir="ltr" autocomplete="email" :aria-invalid="!!errors.email">
                    <p v-if="errors.email" class="mt-1 text-sm text-terracotta">{{ errors.email }}</p>
                </div>

                <div v-if="events.length" class="sm:col-span-2">
                    <label class="label" for="r-match">{{ t('reserve.match') }}</label>
                    <select id="r-match" v-model="form.event_id" class="field">
                        <option value="">{{ t('reserve.match_none') }}</option>
                        <option v-for="e in events" :key="e.id" :value="String(e.id)">{{ eventLabel(e) }}</option>
                    </select>
                    <p v-if="errors.event_id" class="mt-1 text-sm text-terracotta">{{ errors.event_id }}</p>
                </div>

                <div>
                    <label class="label" for="r-date">{{ t('reserve.date') }}</label>
                    <input id="r-date" v-model="form.date" class="field" type="date" :min="today" :max="maxDate" required>
                    <p v-if="closedDay" class="mt-1 text-sm text-terracotta">{{ t('reserve.closed_day') }}</p>
                </div>
                <div>
                    <label class="label" for="r-time">{{ t('reserve.time') }}</label>
                    <select id="r-time" v-model="form.slot" class="field" required :disabled="!slots.length" :aria-invalid="!!errors.slot">
                        <option v-for="s in slots" :key="s.value" :value="s.value">
                            {{ formatClock(s.time, locale) }}{{ s.late ? ` (${formatDate(`${s.date}T12:00:00Z`, locale, { weekday: 'short' })})` : '' }}
                        </option>
                    </select>
                    <p v-if="errors.slot" class="mt-1 text-sm text-terracotta">{{ errors.slot }}</p>
                </div>

                <div>
                    <label class="label" for="r-guests">{{ t('reserve.guests') }}</label>
                    <select id="r-guests" v-model.number="form.guests" class="field">
                        <option v-for="n in guestOptions" :key="n" :value="n">{{ n }}</option>
                    </select>
                    <p v-if="errors.guests" class="mt-1 text-sm text-terracotta">{{ errors.guests }}</p>
                </div>
                <div>
                    <label class="label" for="r-seating">{{ t('reserve.seating') }}</label>
                    <select id="r-seating" v-model="form.seating" class="field">
                        <option value="">{{ t('reserve.seating_any') }}</option>
                        <option value="indoor">{{ t('reserve.seating_indoor') }}</option>
                        <option value="outdoor">{{ t('reserve.seating_outdoor') }}</option>
                        <option value="screens">{{ t('reserve.seating_screens') }}</option>
                    </select>
                </div>

                <div class="sm:col-span-2">
                    <label class="label" for="r-notes">{{ t('reserve.notes') }}</label>
                    <textarea id="r-notes" v-model="form.notes" class="field min-h-28" maxlength="500" :placeholder="t('reserve.notes_hint')" />
                </div>

                <!-- Honeypot: invisible to people, tempting to bots -->
                <div class="absolute -left-[9999px] h-px w-px overflow-hidden" aria-hidden="true">
                    <label for="r-website">Website</label>
                    <input id="r-website" v-model="form.website" tabindex="-1" autocomplete="off">
                </div>

                <div class="sm:col-span-2">
                    <p v-if="failed" class="mb-4 text-sm text-terracotta" role="alert">{{ t('errors.generic') }}</p>
                    <button type="submit" class="btn btn-gold w-full sm:w-auto" :disabled="sending || !slots.length">
                        {{ sending ? t('reserve.sending') : t('reserve.submit') }}
                    </button>
                </div>
            </form>

            <aside class="space-y-10 lg:pt-2">
                <div>
                    <h2 class="mb-3 font-display text-xl">{{ t('home.hours_title') }}</h2>
                    <HoursTable />
                </div>
                <div class="flex flex-col gap-3">
                    <a v-if="site.telLink" :href="site.telLink" class="flex items-center gap-3 hover:text-emerald">
                        <Icon name="phone" :size="20" class="text-emerald" /> <span dir="ltr">{{ site.settings.phone }}</span>
                    </a>
                    <a v-if="site.whatsappLink()" :href="site.whatsappLink()" target="_blank" rel="noopener" class="flex items-center gap-3 hover:text-emerald">
                        <Icon name="whatsapp" :size="20" class="text-emerald" /> {{ t('cta.whatsapp') }}
                    </a>
                </div>
            </aside>
        </div>
    </div>
</template>
