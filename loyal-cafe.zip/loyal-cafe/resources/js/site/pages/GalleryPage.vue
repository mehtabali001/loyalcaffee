<script setup>
import { computed, ref, watch, onBeforeUnmount } from 'vue';
import { useI18n } from 'vue-i18n';
import Icon from '@/shared/Icon.vue';
import PageIntro from '../components/PageIntro.vue';
import LoadState from '../components/LoadState.vue';
import { useSite } from '../stores/site';
import { useAsync } from '../composables/useAsync';

const site = useSite();
const { t } = useI18n();
const { data, error, loading, run } = useAsync(() => site.load('gallery', '/gallery'));

const filter = ref('all');
const items = computed(() => (data.value?.items || []).filter((i) => filter.value === 'all' || i.category === filter.value));
const cats = computed(() => ['all', ...new Set((data.value?.items || []).map((i) => i.category))]);

// Lightbox
const current = ref(-1);
const openAt = (i) => (current.value = i);
const close = () => (current.value = -1);
const step = (d) => (current.value = (current.value + d + items.value.length) % items.value.length);
const onKey = (e) => {
    if (current.value < 0) return;
    const rtl = site.rtl;
    if (e.key === 'Escape') close();
    if (e.key === 'ArrowRight') step(rtl ? -1 : 1);
    if (e.key === 'ArrowLeft') step(rtl ? 1 : -1);
};
watch(current, (v) => {
    document.body.style.overflow = v >= 0 ? 'hidden' : '';
    v >= 0 ? window.addEventListener('keydown', onKey) : window.removeEventListener('keydown', onKey);
});
onBeforeUnmount(() => { window.removeEventListener('keydown', onKey); document.body.style.overflow = ''; });
</script>

<template>
    <div>
        <PageIntro :title="t('gallery.title')" :intro="t('gallery.intro')">
            <div v-if="cats.length > 2" class="mt-10 flex flex-wrap gap-2" role="tablist">
                <button
                    v-for="c in cats" :key="c" type="button" role="tab" :aria-selected="filter === c"
                    class="rounded-full border px-4 py-2 text-sm transition-colors"
                    :class="filter === c ? 'border-emerald bg-emerald text-ivory' : 'border-charcoal/15 hover:border-emerald'"
                    @click="filter = c"
                >{{ t(`gallery.${c}`) }}</button>
            </div>
        </PageIntro>

        <LoadState v-if="!data" :loading="loading" :error="error" @retry="run" />
        <div v-else class="shell pb-24">
            <p v-if="!items.length" class="text-charcoal/70">{{ t('gallery.empty') }}</p>
            <div class="columns-1 gap-4 sm:columns-2 lg:columns-3">
                <button
                    v-for="(g, i) in items" :key="g.id" type="button"
                    class="group mb-4 block w-full break-inside-avoid overflow-hidden rounded-lg text-start"
                    @click="openAt(i)"
                >
                    <img :src="g.image" :alt="g.alt || ''" loading="lazy" class="w-full transition-transform duration-700 ease-lounge group-hover:scale-[1.03]">
                    <span v-if="g.caption" class="block px-1 pt-2 text-sm text-charcoal/70">{{ g.caption }}</span>
                </button>
            </div>
        </div>

        <teleport to="body">
            <div v-if="current >= 0" class="fixed inset-0 z-[70] flex items-center justify-center bg-emerald-night/95 p-4" role="dialog" aria-modal="true" @click.self="close">
                <figure class="max-h-full max-w-5xl text-center">
                    <img :src="items[current].image" :alt="items[current].alt || ''" class="mx-auto max-h-[80vh] rounded-lg object-contain">
                    <figcaption v-if="items[current].caption" class="mt-4 text-ivory/80">{{ items[current].caption }}</figcaption>
                </figure>
                <button type="button" class="absolute end-4 top-4 grid h-12 w-12 place-items-center rounded-full text-ivory hover:bg-ivory/10" :aria-label="t('gallery.close')" @click="close"><Icon name="close" :size="26" /></button>
                <button v-if="items.length > 1" type="button" class="absolute start-3 top-1/2 grid h-12 w-12 -translate-y-1/2 place-items-center rounded-full text-ivory hover:bg-ivory/10" :aria-label="t('gallery.prev')" @click="step(-1)"><Icon name="chevron" :size="26" class="rotate-180 rtl:rotate-0" /></button>
                <button v-if="items.length > 1" type="button" class="absolute end-3 top-1/2 grid h-12 w-12 -translate-y-1/2 place-items-center rounded-full text-ivory hover:bg-ivory/10" :aria-label="t('gallery.next')" @click="step(1)"><Icon name="chevron" :size="26" class="rtl:rotate-180" /></button>
            </div>
        </teleport>
    </div>
</template>
