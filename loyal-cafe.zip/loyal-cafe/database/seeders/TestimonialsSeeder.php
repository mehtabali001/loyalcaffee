<?php

namespace Database\Seeders;

use App\Models\Testimonial;
use Illuminate\Database\Seeder;

/**
 * Seeded INACTIVE on purpose: publishing invented reviews is misleading (and against Google's
 * policies). Paste real Google reviews in Admin → Reviews and switch them on.
 */
class TestimonialsSeeder extends Seeder
{
    public function run(): void
    {
        Testimonial::query()->delete();
        (new Testimonial(['author' => 'Replace with a real guest', 'rating' => 5, 'source' => 'google', 'is_active' => false]))
            ->fillTranslations(['content' => ['en' => 'Copy a real Google review here and activate it.', 'ar' => 'انسخ هنا مراجعة حقيقية من جوجل ثم فعّلها.']])
            ->save();
    }
}
