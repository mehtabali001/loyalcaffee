<?php

namespace Database\Seeders;

use App\Models\MenuCategory;
use App\Models\MenuItem;
use Illuminate\Database\Seeder;

/**
 * Starter menu. Prices are placeholders in AED — replace them in Admin → Menu
 * with the cafe's real price list before launch.
 */
class MenuSeeder extends Seeder
{
    public function run(): void
    {
        MenuItem::query()->delete();
        MenuCategory::query()->delete();

        $menu = [
            ['shisha', 'shisha', ['Shisha', 'الشيشة'], ['Hand-packed to order, fresh coals all evening.', 'تُحضّر عند الطلب مع تبديل الفحم طوال السهرة.'], [
                [['Double Apple', 'تفاحتين'], ['The classic, aniseed-sweet and smooth.', 'النكهة الكلاسيكية بلمسة يانسون ناعمة.'], 75, ['signature', 'popular'], true],
                [['Grape Mint', 'عنب ونعناع'], null, 75, ['popular'], false],
                [['Lemon Mint', 'ليمون ونعناع'], null, 75, [], false],
                [['Blueberry', 'توت أزرق'], null, 75, [], false],
                [['Love 66', 'لوف 66'], ['Passion fruit, melon and mint.', 'باشن فروت وشمام ونعناع.'], 80, ['popular'], false],
                [['Loyal House Blend', 'خلطة لويال الخاصة'], ['Ask your shisha host for tonight\'s mix.', 'اسأل مسؤول الشيشة عن خلطة الليلة.'], 90, ['signature', 'new'], true],
            ]],
            ['coffee', 'coffee', ['Coffee', 'القهوة'], ['Specialty beans, pulled and poured with care.', 'حبوب مختصة تُحضّر بعناية.'], [
                [['Espresso', 'إسبريسو'], null, 14, [], false],
                [['Americano', 'أمريكانو'], null, 16, [], false],
                [['Cappuccino', 'كابتشينو'], null, 20, [], false],
                [['Flat White', 'فلات وايت'], null, 22, ['popular'], false],
                [['Spanish Latte', 'سبانيش لاتيه'], ['Sweet condensed milk, double shot.', 'حليب مكثف محلى مع جرعتين إسبريسو.'], 24, ['signature', 'popular'], true],
                [['V60 Pour Over', 'في 60'], ['Single origin, ask for today\'s bean.', 'محصول أحادي المصدر، اسأل عن حبوب اليوم.'], 28, [], false],
                [['Turkish Coffee', 'قهوة تركية'], null, 15, [], false],
                [['Karak Chai', 'شاي كرك'], null, 8, ['popular'], false],
            ]],
            ['avocado-juices', 'juice', ['Avocado & Fresh Juice', 'الأفوكادو والعصائر الطازجة'], ['Pressed and blended to order.', 'تُعصر وتُخلط عند الطلب.'], [
                [['Avocado Shake', 'شيك أفوكادو'], ['With honey, nuts and a scoop of cream.', 'مع العسل والمكسرات والقشطة.'], 26, ['signature', 'popular'], true],
                [['Loyal Avocado Cocktail', 'كوكتيل أفوكادو لويال'], ['Layers of avocado, mango and strawberry.', 'طبقات من الأفوكادو والمانجو والفراولة.'], 30, ['signature'], true],
                [['Fresh Orange', 'برتقال طازج'], null, 18, [], false],
                [['Lemon Mint', 'ليمون ونعناع'], null, 18, ['popular'], false],
                [['Mango', 'مانجو'], null, 20, [], false],
                [['Strawberry', 'فراولة'], null, 20, [], false],
            ]],
            ['mocktails', 'glass', ['Mojitos & Mocktails', 'موهيتو وموكتيل'], null, [
                [['Classic Mojito', 'موهيتو كلاسيك'], null, 24, [], false],
                [['Passion Fruit Mojito', 'موهيتو باشن فروت'], null, 26, ['popular'], false],
                [['Blue Lagoon', 'بلو لاجون'], null, 26, [], false],
                [['Iced Hibiscus', 'كركديه مثلج'], null, 20, ['new'], false],
            ]],
            ['breakfast', 'sun', ['Breakfast', 'الفطور'], ['Served all day.', 'يُقدّم طوال اليوم.'], [
                [['Shakshuka', 'شكشوكة'], ['Eggs baked in spiced tomato, warm bread.', 'بيض مطهو في صلصة طماطم متبلة مع خبز دافئ.'], 32, ['popular'], false],
                [['Foul Medames', 'فول مدمس'], null, 25, ['vegetarian'], false],
                [['Halloumi & Zaatar Toast', 'توست حلوم وزعتر'], null, 30, ['vegetarian'], false],
                [['Avocado Toast', 'توست أفوكادو'], ['Sourdough, poached egg, chilli flakes.', 'خبز العجين المخمر مع بيض مسلوق ورقائق الفلفل.'], 38, ['new'], true],
            ]],
            ['food', 'plate', ['Food', 'الأطباق'], null, [
                [['Loyal Club Sandwich', 'كلوب ساندويتش لويال'], null, 42, ['popular'], false],
                [['Beef Burger', 'برجر لحم'], ['Cheddar, caramelised onion, fries.', 'شيدر وبصل مكرمل مع البطاطا.'], 48, [], false],
                [['Grilled Chicken Platter', 'طبق دجاج مشوي'], null, 52, [], false],
                [['Fattoush', 'فتوش'], null, 26, ['vegan'], false],
                [['Match Night Sharing Box', 'بوكس المباراة للمشاركة'], ['Wings, sliders, fries and dips for four.', 'أجنحة وسلايدرز وبطاطا وصلصات لأربعة أشخاص.'], 120, ['sharing'], true],
            ]],
            ['desserts', 'dessert', ['Desserts', 'الحلويات'], null, [
                [['Kunafa', 'كنافة'], null, 32, ['popular'], false],
                [['Pistachio Cheesecake', 'تشيز كيك بالفستق'], null, 34, ['signature'], true],
                [['Lotus Cake', 'كيكة لوتس'], null, 30, [], false],
            ]],
        ];

        foreach ($menu as $ci => [$slug, $icon, $name, $desc, $items]) {
            $cat = new MenuCategory(['slug' => $slug, 'icon' => $icon, 'is_active' => true, 'sort_order' => $ci + 1]);
            $cat->fillTranslations([
                'name' => ['en' => $name[0], 'ar' => $name[1]],
                'description' => $desc ? ['en' => $desc[0], 'ar' => $desc[1]] : null,
            ])->save();

            foreach ($items as $ii => [$n, $d, $price, $tags, $featured]) {
                $item = new MenuItem([
                    'menu_category_id' => $cat->id, 'price' => $price, 'tags' => $tags,
                    'is_featured' => $featured, 'is_available' => true, 'is_active' => true, 'sort_order' => $ii + 1,
                ]);
                $item->fillTranslations([
                    'name' => ['en' => $n[0], 'ar' => $n[1]],
                    'description' => $d ? ['en' => $d[0], 'ar' => $d[1]] : null,
                ])->save();
            }
        }
    }
}
