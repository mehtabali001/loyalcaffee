<?php

namespace Database\Seeders;

use App\Models\GalleryItem;
use Illuminate\Database\Seeder;

/** Placeholder artwork — swap for the professional shoot (Brand Guide §3.6) via Admin → Gallery. */
class GallerySeeder extends Seeder
{
    public function run(): void
    {
        GalleryItem::query()->delete();
        $items = [
            ['interior', 'interior.svg', ['The lounge at golden hour', 'اللاونج وقت الغروب'], true],
            ['shisha', 'shisha.svg', ['Fresh coals, slow evenings', 'فحم طازج وأمسيات هادئة'], true],
            ['drinks', 'coffee.svg', ['Spanish latte, poured to order', 'سبانيش لاتيه يُحضّر عند الطلب'], true],
            ['match-nights', 'screens.svg', ['Screens ready for kick-off', 'الشاشات جاهزة لصافرة البداية'], true],
            ['drinks', 'juice.svg', ['Avocado cocktail', 'كوكتيل الأفوكادو'], false],
            ['food', 'food.svg', ['Sharing plates for the table', 'أطباق للمشاركة على الطاولة'], false],
        ];
        foreach ($items as $i => [$cat, $file, $caption, $featured]) {
            (new GalleryItem(['category' => $cat, 'image' => "/images/placeholders/$file", 'is_featured' => $featured, 'is_active' => true, 'sort_order' => $i + 1]))
                ->fillTranslations(['caption' => ['en' => $caption[0], 'ar' => $caption[1]]])->save();
        }
    }
}
