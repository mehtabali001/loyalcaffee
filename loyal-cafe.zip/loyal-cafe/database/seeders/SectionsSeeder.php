<?php

namespace Database\Seeders;

use App\Models\Section;
use Illuminate\Database\Seeder;

/** Home page building blocks, copy written to the Brand Voice guide (§1.5). */
class SectionsSeeder extends Seeder
{
    public function run(): void
    {
        Section::query()->where('page', 'home')->delete();

        $blocks = [
            [
                'type' => 'hero',
                'title' => ['en' => 'Stay a while.', 'ar' => 'خذ راحتك.'],
                'subtitle' => ['en' => 'Specialty coffee by day, premium shisha by night — on Al Marami Street, Madinat Zayed.', 'ar' => 'قهوة مختصة في النهار وشيشة فاخرة في المساء، في شارع المرامي بمدينة زايد.'],
                'cta_label' => ['en' => 'Reserve a table', 'ar' => 'احجز طاولة'],
                'cta_link' => '/reserve',
                'image' => '/images/placeholders/hero-day.svg',
                'image_secondary' => '/images/placeholders/hero-night.svg',
                'data' => ['secondary_label' => ['en' => 'See the menu', 'ar' => 'تصفّح القائمة'], 'secondary_link' => '/menu'],
            ],
            [
                'type' => 'story',
                'title' => ['en' => 'Where Abu Dhabi slows down', 'ar' => 'حيث تهدأ أبوظبي'],
                'body' => [
                    'en' => "The best moments happen when people gather without rushing. In a city that moves fast, Loyal is the pause — deep green walls, warm gold light, and a table that's always ready for one more chair.\n\nA business lunch turns into a long coffee. Families settle in for the evening. Friends claim their corner to watch the match.",
                    'ar' => "أجمل اللحظات تأتي حين يجتمع الناس دون استعجال. في مدينة سريعة الإيقاع، لويال هو استراحتك: جدران خضراء عميقة، وضوء ذهبي دافئ، وطاولة تتسع دائماً لكرسي إضافي.\n\nغداء عمل يتحول إلى قهوة طويلة، وعائلات تقضي أمسيتها براحة، وأصدقاء يحجزون ركنهم المفضل لمشاهدة المباراة.",
                ],
                'image' => '/images/placeholders/interior.svg',
            ],
            [
                'type' => 'day_night',
                'title' => ['en' => 'One place, two moods', 'ar' => 'مكان واحد بمزاجين'],
                'data' => [
                    'day' => [
                        'title' => ['en' => 'By day', 'ar' => 'في النهار'],
                        'body' => ['en' => 'Flat whites and V60 pours, avocado shakes, fresh juice and a quiet corner with Wi-Fi.', 'ar' => 'فلات وايت وقهوة V60، وشيك أفوكادو، وعصائر طازجة، وركن هادئ مع واي فاي.'],
                        'time' => ['en' => 'From 8 AM', 'ar' => 'من 8 صباحاً'],
                        'image' => '/images/placeholders/coffee.svg',
                    ],
                    'night' => [
                        'title' => ['en' => 'By night', 'ar' => 'في المساء'],
                        'body' => ['en' => 'Hand-packed shisha, low gold light, the terrace breeze and the big screens on match nights.', 'ar' => 'شيشة محضّرة بعناية، وإضاءة ذهبية هادئة، ونسمة الجلسات الخارجية، والشاشات الكبيرة في ليالي المباريات.'],
                        'time' => ['en' => 'Until 3 AM', 'ar' => 'حتى 3 فجراً'],
                        'image' => '/images/placeholders/shisha.svg',
                    ],
                ],
            ],
            [
                'type' => 'featured_menu',
                'title' => ['en' => 'Guests keep ordering these', 'ar' => 'الأكثر طلباً عند ضيوفنا'],
                'cta_label' => ['en' => 'See the full menu', 'ar' => 'القائمة كاملة'],
                'cta_link' => '/menu',
            ],
            [
                'type' => 'matches',
                'title' => ['en' => 'Match nights on the big screens', 'ar' => 'ليالي المباريات على الشاشات الكبيرة'],
                'subtitle' => ['en' => 'Every big game, live. Book early for derbies and finals.', 'ar' => 'كل المباريات الكبرى مباشرة. احجز مبكراً للديربي والنهائيات.'],
                'cta_label' => ['en' => 'All fixtures', 'ar' => 'جدول المباريات'],
                'cta_link' => '/match-nights',
            ],
            ['type' => 'offers', 'title' => ['en' => 'This week at Loyal', 'ar' => 'هذا الأسبوع في لويال']],
            [
                'type' => 'gallery',
                'title' => ['en' => 'Take a look inside', 'ar' => 'ألقِ نظرة من الداخل'],
                'cta_label' => ['en' => 'Open the gallery', 'ar' => 'افتح المعرض'],
                'cta_link' => '/gallery',
            ],
            ['type' => 'testimonials', 'title' => ['en' => 'From our guests', 'ar' => 'من ضيوفنا']],
            [
                'type' => 'visit',
                'title' => ['en' => 'Find us on Al Marami Street', 'ar' => 'تجدنا في شارع المرامي'],
                'subtitle' => ['en' => 'Free parking right outside.', 'ar' => 'مواقف مجانية أمام المدخل.'],
            ],
        ];

        foreach ($blocks as $i => $b) {
            $s = new Section(['page' => 'home', 'type' => $b['type'], 'cta_link' => $b['cta_link'] ?? null,
                'image' => $b['image'] ?? null, 'image_secondary' => $b['image_secondary'] ?? null, 'data' => $b['data'] ?? null, 'is_active' => true, 'sort_order' => $i + 1]);
            $s->fillTranslations($b)->save();
        }
    }
}
